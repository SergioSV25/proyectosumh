<!DOCTYPE html>
<html>
    <body>
        <h1>Hola, <?php echo e($nombre); ?></h1>
    </body>
</html>