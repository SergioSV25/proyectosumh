<!DOCTYPE html>
<html>
    <body>
        <h1>Mostrando el articulo <?php echo e($id); ?></h1>
    </body>
</html>